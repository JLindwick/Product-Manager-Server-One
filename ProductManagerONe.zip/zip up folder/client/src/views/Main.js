import React, { useEffect, useState } from 'react'
import ProductManagerForm from '../components/ProductManagerForm'
export default () => {
    return (
        <>
            <ProductManagerForm/>
        </>
    )
}
